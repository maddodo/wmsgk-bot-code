<?php
/*
 * @Author: zeyudada MuXiaoGuo
 * @Date: 2022-01-16
 * @LastEditTime: 2022-04-30 17:05:22
 * @Description: 身份证验证
 * @Q Q: zeyunb@vip.qq.com(1776299529)
 * @E-mail: admin@zeyudada.cn
 * 
 * Copyright (c) 2022 by zeyudada, All Rights Reserved. 
 * 数据来自：本地数据库+API
 */

require_once __DIR__ . '/IdentityCard.php'; //引入身份证验证类
require_once APP_PLUGIN_PATH . '/sqlite/medoo_1.6/Medoo.php'; //引入SQLite框架
require_once APP_PLUGIN_PATH . '/Funlibs.php'; //引入函数库
use Medoo\Medoo; //这个必须放在函数外不然会报错

/**给返回参数默认值*/
$code = -1;
$msg = 'error';
$data = [];

$card = empty($_GET['card']) ? $_POST['card'] : $_GET['card'];
$name = empty($_GET['name']) ? $_POST['name'] : $_GET['name'];

if (empty($card) || empty($name)) {
    goto output;
} else {
    if (!IdentityCard::isValid($card)) { //判断身份证格式
        $code = -3;
        $msg = 'Id Card Format error';
        goto output;
    }
    if (strlen($name) > 12) { //判断姓名长度
        $code = -3;
        $msg = 'name length error';
        goto output;
    }
    /** 初始化 */
    $database = new medoo([ // 实例化
        'database_type' => 'sqlite', //数据库类型
        'database_file' => APP_PLUGIN_PATH . '/sqlite/library/checkIdCard.db' //sqlite数据库位置
    ]);
        $webData = json_decode(httpCurl('https://maple.icesimba.cn/maple/notoken/realname/auth', [
            'post' => '{"game_id":"zjlszydjd","game_secret":"941ca55b905e2546ec5bec00c978191c","idname":"' . $name . '","idcard":"' . $card . '","user_id":"30-1C-08-6C-CF-8A-D1-A3"}',
            'Header' => [
                'Content-Type:application/json;charset=utf-8',
                'Host:maple.icesimba.cn',
                'User-Agent:giraffe/5 CFNetwork/1220.1 Darwin/20.3.0',
                'X-Unity-Version:2019.4.19f1c1'
            ]
        ]), true);

        /*判断身份证与姓名是否匹配*/
        if ($webData['code'] == 0) { //匹配
            $code = 200;
            $msg = 'success';
            $check = '1';
        } else if ($webData['code'] == 112007) { //不匹配
            $code = 200;
            $msg = 'success';
            $check = '2';
        } else if ($webData['code'] == 112003) { //身份证格式错误
            $code = -3;
            $msg = 'Id Card Format error';
            goto output;
        } else {
            $code = -4;
            goto output;
        }
        $data = [
            'name' => $name,
            'card' => $card,
            'check' => $check
        ];
        $SQL = "INSERT INTO checkIdCard ('card', 'name', 'check') VALUES ('{$card}', '{$name}', {$check})";
        $cheData = $database->query($SQL)->fetchAll(); //入库
}
output:
$result = [ //返回数据统一处理
    'code' => $code,
    'msg' => $msg,
    'data' => $data
];
die(json_encode($result, JSON_PRETTY_PRINT));
