<?php
/**
 * Api name:手机空号查询
 * Author:MuXiaoGuo
 * Update time:----
 * 数据来自：本地数据库+API
 */
require_once dirname(dirname(__DIR__)).'/sqlite/medoo_1.6/Medoo.php';//引入SQLite框架
require_once dirname(dirname(dirname(__DIR__))).'/public/assets/Funlibs.php';//引入函数库
use Medoo\Medoo;//这个必须放在函数外不然会报错
infoAction();

function infoAction(){
	/**给返回参数默认值*/
	$code = -1;
	$msg = 'error';
	$data = [];
	
	$phoneNum = empty($_GET['phoneNum']) ? $_POST['phoneNum'] : $_GET['phoneNum'];//垃圾名称
	if (!$phoneNum) {
		$msg = 'error';
	}else{
		/** 初始化 */
		$database = new medoo([// 实例化
			'database_type' => 'sqlite',//数据库类型
			'database_file' => dirname(dirname(__DIR__)).'/sqlite/library/chePhone.db'//sqlite数据库位置
		]);
		$profile = $database->get("PhoneNumber", [
			"Phone",
			"Status"
		], [
			"Phone" => $phoneNum//条件
		]);
		if ($profile['Phone']) {//判断从数据库获取的内容是否为空  为空则使用接口 并写入数据库
			$Status = $profile['Status'];
		    $code = 200;
			$msg = 'success';
			/*1.实号(活跃)|2.风险|3.空号|4.沉默(不常用)*/
		    if ($Status == 1) {
                $data = [
                    'phone' => $phoneNum,//实号
					'status' => '1'
				];
            }else if ($Status == 2) {//风险
                $data = [
                    'phone' => $phoneNum,
					'status' => '2'
				];
            }else if ($Status == 3) {//空号
                $data = [
                    'phone' => $phoneNum,
					'status' => '3'
				];
            }else if ($Status == 4) {//沉默(不常用)
                $data = [
                    'phone' => $phoneNum,
					'status' => '4'
				];
            }
		}else{
		    $code = -4;
	        /*$jsonData = json_decode(httpCurl('http://openapi.xunmiao.net/api/blank/check',[
                'post' => 'account=VgbIEWa4sRSrcqR8&password=j1D8uzftisd1ABPwLpbuc7CyK6Awar5C&phone='.$phoneNum
	        ]),true);
		    $jsonData = json_decode($jsonData['data'],true);//因为这里面还有一个JSON所以需要取出来后再次绑定
		    if ($jsonData != '') {
    		    $code = 200;
    			$msg = 'success';
		        if ($jsonData['blank'][0] == $phoneNum) {//空号
    		        $data = [
                        'phone' => $phoneNum,
    					'status' => '3'
    				];
    				$SQL = 'INSERT INTO PhoneNumber VALUES (NULL, '.$phoneNum.',3)';
    		    }else if ($jsonData['unknow'][0] == $phoneNum) {//沉默(不常用)
    		        $data = [
                        'phone' => $phoneNum,
    					'status' => '4'
    				];
    				$SQL = 'INSERT INTO PhoneNumber VALUES (NULL, '.$phoneNum.',4)';
    		    }else if ($jsonData['active'][0] == $phoneNum) {//实号
    		        $data = [
                        'phone' => $phoneNum,
    					'status' => '1'
    				];
    				$SQL = 'INSERT INTO PhoneNumber VALUES (NULL, '.$phoneNum.',1)';
    		    }else if ($jsonData['risk'][0] == $phoneNum) {//风险
    		        $data = [
                        'phone' => $phoneNum,
    					'status' => '2'
    				];
    				$SQL = 'INSERT INTO PhoneNumber VALUES (NULL, '.$phoneNum.',2)';
    		    }
    		    $cheData = $database->query($SQL)->fetchAll();//入库
		    }else {
		        $msg = '使用API查询时发生错误';
		    }*/
		}
	}
	$result = [//返回数据统一处理
        'code' => $code,
        'msg' => $msg,
        'data' => $data
    ];
    die(json_encode($result,320));    //json返回
}
?>