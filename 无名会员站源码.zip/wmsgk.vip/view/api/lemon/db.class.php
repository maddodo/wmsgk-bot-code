<?php
class DB
{
    public $link;

    public function __construct()
    {
        $DbConfig = [
            'host' => 'localhost',
            'port' => 6603,
            'user' => 'readonlyrk',
            'pwd' => 'NfZ6KUUpuLkJjqZ',
            'name' => 'people',
            'long' => false,
        ];
        $this->link = mysqli_connect($DbConfig['host'], $DbConfig['user'], $DbConfig['pwd'], $DbConfig['name'], $DbConfig['port']);
        if (!$this->link) exit(mysqli_connect_error());
    }

    //执行查询
    public function query($sql)
    {
        return mysqli_query($this->link, $sql);
    }

    //转义
    public function escape($txt){
        return mysqli_real_escape_string($this->link, $txt);
    }

    //查询数据
    public function get_row($sql)
    {
        $res = $this->query($sql);
        if (!$res) return false;
        return mysqli_fetch_assoc($res);
    }

    //查询全部数据
    public function getAll($sql)
    {
        $res = $this->query($sql);
        while ($row =  mysqli_fetch_assoc($res)) {
            $data[] = $row;
        }
        return $data;
    }

    //报错信息
    public function error()
    {
        return mysqli_error($this->link);
    }

    //关闭数据库链接
    public function close()
    {
        return mysqli_close($this->link);
    }

    private function __destruct()
    {
        $this->close();
    }
}
