<?php
header("Access-Control-Allow-Origin:*; charset=utf-8");
header("Access-Control-Allow-Methods:GET,POST");
if (!isset($_GET['zeyudadadebug'])) error_reporting(0);

$cha = empty($_GET['cha']) ? addslashes($_POST['cha']) : addslashes($_GET['cha']);
if (empty($cha)) {
    include(__DIR__ . '/public.html');
    die();
}


header('content-type:text/plain');
if (is_numeric($cha) && strlen($cha) == 11 && $cha > 13000000000) $type = 'mobile';
elseif (filter_var($cha, FILTER_VALIDATE_EMAIL)) $type = 'mail';
elseif (preg_match_all("/^([\x80-\xff])+$/", $cha) > 0) $type = 'name';
else die('没识别出来到底是什么类型');

if(empty($type)) die('not here');
require(__DIR__.'/db.class.php');
$DB = new DB;
$cha = $DB->escape($cha);

function arr2txt($arr)
{
    $known = [
        'name' => '姓名',
        'mobile' => '手机',
        'mail' => '邮箱',
        'address' => '地址',
        'provinces' => '省',
        'city' => '市',
        'zip' => '邮编',
        'place' => '地址',
        'sfz' => '身份证',
        'mail' => '邮箱',
        'extra' => '其他',
        'extra2' => '其他',
        'jifen' => '积分',
        'pwd' => '密码',
        'user' => '用户名',
        'date' => '日期',
        'car' => '车牌号',
        'motor' => '引擎',
        'color' => '颜色',
        'carname' => '车名',
        'source' => '来源'
    ];
    if (empty($arr)) return;
    $echo = '';
    foreach ($arr as $key => $value) {
        if (is_array($value) && !empty($value)) {
            foreach ($value as $k => $v) {
                if(!empty($v) && $v != '\N') $echo .= "{$known[$k]}:{$v} ";
            }
            $echo .= "\n";
        } else $echo .= "{$known[$key]}:{$value} ";
    }
    return $echo . "\n";
}
$echo = '';
switch ($type) {
    case 'name':
        $rs = $DB->getAll("SELECT * FROM `people`.`new` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`car` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`kf` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`jingdong` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`fixman` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`fixman2` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`jxydvip` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`shunfeng` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`vancl` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`police` WHERE `name` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        break;

    case 'mobile':
        $rs = $DB->getAll("SELECT * FROM `people`.`new` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`car` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`kf` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`jingdong` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`fixman` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`fixman2` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`jxydvip` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`shunfeng` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`vancl` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`police` WHERE `mobile` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        break;

    case 'mail':
        $rs = $DB->getAll("SELECT * FROM `people`.`new` WHERE `mail` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`jingdong` WHERE `mail` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        $rs = $DB->getAll("SELECT * FROM `people`.`kf` WHERE `mail` = '{$cha}' LIMIT 2000");
        $echo .= arr2txt($rs);
        break;
    
    default:
        # code...
        break;
}
if(empty($echo)) $echo = "猎魔没有数据";


if(!empty($_GET['limit'])){
	die(mb_substr($echo,0,$_GET['limit'],'UTF8'));
}else{
	die($echo);
}