<?php
/**
 * Api name:ICP备案查询
 * Author:MuXiaoGuo
 * Update time:2022/1/19
 * 数据来自：站长工具ICP查询+爱站ICP查询+数据库
 */
require_once dirname(dirname(dirname(__DIR__))).'/public/assets/Funlibs.php';//引入函数库
require_once dirname(dirname(__DIR__)).'/sqlite/medoo_1.6/Medoo.php';//引入SQLite框架
use Medoo\Medoo;//这个必须放在函数外不然会报错
infoAction();

function infoAction() {
    /**给返回参数默认值*/
    $code = -1;
    $msg = 'error';
    $data = [];
    
    $url = empty($_GET['url']) ? $_POST['url'] : $_GET['url'];//需要查询的链接
    $type = empty($_GET['type']) ? $_POST['type'] : $_GET['type'];//查询接口选择

	if (empty($url)) {
		$msg = 'error';
	}else{
        $tmpChar = substr($url,-1)!='/' ? $url.'/' : $url ;//取出域名最后一个字符为末尾不是 / 的链接加上 /
        $isMatched = preg_match('/\.(\w+\.\w+)\/?/', $tmpChar, $matches);//匹配出链接主域名如：https://api.muxiaoguo.cn/ 将获得muxiaoguo.cn
        $url = $isMatched > 0 ? $matches[1] : $url;//判断是否取出主域名若去除则使用匹配到的文本，否则使用原文本
        
        /*判断是否存在这个类型*/
        // if (!in_array($type,['Az','Cz'])) $type = 'Cz';//默认使用Cz接口
        $type = 'Cz';//目前只使用Cz接口
        $tmpTxt = $type=='Az' ? 'AizhaN' : 'ChinaZ';//根据type参数判断数据库表名
        
        /** 初始化数据库 */
        $database = new medoo([// 实例化
        	'database_type' => 'sqlite',//数据库类型
        	'database_file' => dirname(dirname(__DIR__)).'/sqlite/library/webICP.db'//sqlite数据库位置
        ]);
        $profile = $database->get($tmpTxt, [//在数据库内查找域名
			'url',
			'organizer_name',
			'nature',
			'license',
			'website_name',
			'website_home',
			'audit_time',
			'add_time'
		], [
			"url" => $url//条件
		]);
		
		
	    $timesRangeCount = diffBetweenDay(date('Y-m-d H:m:s'),$profile['add_time'],true);//取出 当前时间与添加时间 所间隔天数
		/*判断数据库中是否存在此域名且缓存时间小于30天*/
		if ($profile && $timesRangeCount < 30) {
                /*直接使用数据库内容*/
                $code = 200;
                $msg = 'success';
                $data = [
                	'url' => $profile['url'],
                	'organizer_name' => $profile['organizer_name'],
                	'nature' => $profile['nature'],
                	'license' => $profile['license'],
                	'website_name' => $profile['website_name'],
                	'website_home' => $profile['website_home'],
                	'audit_time' => $profile['audit_time']
                ];
		} else {
            /* 否则调用第三方接口 */
            if ($tmpTxt == 'AizhaN') {
                $tempData = AizhaN($url);//调用爱站接口
            } else if ($tmpTxt == 'ChinaZ') {
                $tempData = ChinaZ($url);//调用站长工具接口
            }
            
            $code = $tempData['code'];
            $msg = $tempData['msg'];
            $data = $tempData['data'];
            
            if ($code = 200 && !empty($data['url'])) {
                if ($timesRangeCount > 30) {
                    /*更新数据库内容*/
                    $profile = $database->update($tmpTxt, [
                    	'organizer_name' => $data['organizer_name'],
                    	'nature' => $data['nature'],
                    	'license' => $data['license'],
                    	'website_name' => $data['license'],
                    	'website_home' => $data['website_home'],
                    	'audit_time' => $data['audit_time'],
                    	'add_time' => date('Y-m-d H:m:s')
                    ], [
                    	'url' => $url//条件
                    ]);
                } else {
                    /*新域名入库*/
                    $SQL = "INSERT INTO {$tmpTxt} ('url', 'organizer_name', 'nature', 'license', 'website_name', 'website_home', 'audit_time') VALUES ('".$data['url']."', '".$data['organizer_name']."', '".$data['nature']."', '".$data['license']."', '".$data['website_name']."', '".$data['website_home']."', '".$data['audit_time']."')";
                    $cheData = $database->query($SQL)->fetchAll();//入库
                }
            } else {
                if ($profile) {
                    /*接口调用失败直接使用数据库内容*/
                    $code = 200;
                    $msg = 'success';
                    $data = [
                    	'url' => $profile['url'],
                    	'organizer_name' => $profile['organizer_name'],
                    	'nature' => $profile['nature'],
                    	'license' => $profile['license'],
                    	'website_name' => $profile['website_name'],
                    	'website_home' => $profile['website_home'],
                    	'audit_time' => $profile['audit_time']
                    ];
                }else {
                    $code = -4;
                }
            }
		}
	}
	$result = [//返回数据统一处理
		'code' => $code,
		'msg' => $msg,
        'data' => $data
    ];
    die(json_encode($result,320));    //json返回
}
#################################################
function ChinaZ($url) {
    $str = httpCurl("http://icp.chinaz.com/{$url}");
	if (!$str) {
	    $tempData['code'] = -4;
		$tempData['msg'] = '获取错误';
	}else{
        $isMatched = preg_match('/k">(.*?)<\/a><\/span>的信息[\S\s]*?主办单位名称[\S\s]*?">(.*?)<\/a>[\S\s]*?主办单位性质[\S\s]*?fwnone">(.*?)<\/strong>[\S\s]*?网站备案\/许可证号[\S\s]*?<font>(.*?)<\/font>[\S\s]*?[\S\s]*?网站名称[\S\s]*?<p>(.*?)<\/p>[\S\s]*?网站首页网址[\S\s]*?Wzno">(.*?)<\/p>[\S\s]*?审核时间[\S\s]*?<p>(.*?)<\/p>/', $str, $matches);//使用正则匹配数据
		if (!$isMatched) {
			$tempData['code'] = -5;
			$tempData['msg'] = '未查询到备案信息';
		}else{
			$tempData['code'] = 200;
			$tempData['msg'] = 'success';
			$tempData['data'] = [
				'url' => $matches[1],
				'organizer_name' => $matches[2],
				'nature' => $matches[3],
				'license' => $matches[4],
				'website_name' => $matches[5],
				'website_home' => $matches[6],
				'audit_time' => $matches[7]
			];
		}
	}
	return $tempData;
}
function AizhaN($url) {
    $str = httpCurl("https://icp.aizhan.com/{$url}/",[
        'Header'=>[
            'referer: https://icp.aizhan.com/'
        ],
        'GetCookie'=> true
    ]);
    $str = $str['body'];
    if(strstr($str,'您的查询太频繁了,请稍后查询! 谢谢您的使用')) {
        $tempData['code'] = -4;
    	$tempData['msg'] = '源站限制';
    }else if (!$str) {
        $tempData['code'] = -4;
    	$tempData['msg'] = '获取错误';
    }else{
        $isMatched = preg_match('/主办单位名称<\/td>[\S\s]*?<td>(.*?)<\/td>[\S\s]*?主办单位性质<\/td>[\S\s]*?<td>(.*?)<\/td>[\S\s]*?网站备案\/许可证号<\/td>[\S\s]*?<td><span>(.*?)<\/span><\/td>[\S\s]*?网站名称<\/td>[\S\s]*?<td>(.*?)<\/td>[\S\s]*?网站首页网址<\/td>[\S\s]*?<td>(.*?)<\/td>[\S\s]*?网站域名<\/td>[\S\s]*?<td>(.*?)<\/td>[\S\s]*?审核时间<\/td>[\S\s]*?<td><span>(.*?)<\/span><\/td>/', $str, $matches);//使用正则匹配数据
        //存在 object 字符串则代表没有该域名信息
        if (strpos($matches[6],'object[') > 0){
            $tempData['code'] = -5;
    		$tempData['msg'] = '未查询到备案信息';
        }else if (!$isMatched) {
    		$tempData['code'] = -5;
    		$tempData['msg'] = '未查询到备案信息';
    	}else{
    		$tempData['code'] = 200;
    		$tempData['msg'] = 'success';
    		$tempData['data'] = [
    			'url' => $matches[6],
    			'organizer_name' => $matches[1],
    			'nature' => $matches[2],
    			'license' => $matches[3],
    			'website_name' => $matches[4],
    			'website_home' => $matches[5],
    			'audit_time' => $matches[7]
    		];
    	}
    }
    return $tempData;
}
?>