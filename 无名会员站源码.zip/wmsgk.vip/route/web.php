<?php

// 前台首页
Route::get("/", function () {
    header('location:/user');
});

//详情页面
Route::get("/doc/{id}.html", "IndexController@doc");

//接口公共通道
Route::any("/api/{apiVal}", "IndexController@api");

// 接口列表
// Route::any("/v1/apilist", "IndexController@getapilist");

#用户#################################################

//用户登录页
Route::get("/user/login.html", "User/IndexController@login");

//用户注册页
Route::get("/user/register.html", "User/IndexController@register");

//找回密码页
Route::get("/user/forget.html", "User/IndexController@forget");

//白名单 
Route::get("/user/whitelist.html", "User/IndexController@whitelist");

//用户首页
Route::get("/user", "User/IndexController@index");
Route::get("/user/", "User/IndexController@index");
Route::get("/user/index.html", "User/IndexController@index");
Route::get("/user/console.html", "User/IndexController@console");

//商品列表
Route::get("/user/goods.html", "User/IndexController@goods");

//购买记录
Route::get("/user/buyapi.html", "User/IndexController@buyapi");

//充值记录
Route::get("/user/buypay.html", "User/IndexController@buypay");

//自助充值
Route::get("/user/pay.html", "User/IndexController@pay");

//修改密码
Route::get("/user/passwd.html", "User/IndexController@passwd");

//商品订单页
Route::get("/user/order/{id}", "User/IndexController@order");

//已购接口
Route::get("/user/owned.html", "User/IndexController@owned");

//配置接口
Route::get("/user/apiedit/{id}", "User/IndexController@apiedit");

//登录验证码
Route::get("/code/login", function () {
    $code = "logincode";
    require APP_VIEW_PATH . "user/code.php";
});

//注册验证码
Route::get("/code/register", function () {
    $code = "registercode";
    require APP_VIEW_PATH . "user/code.php";
});

//注册验证码
Route::get("/code/forget", function () {
    $code = "forgetcode";
    require APP_VIEW_PATH . "user/code.php";
});

#用户数据处理#####################################################

//修改密钥 
Route::post("/user/owned", "User/HandleController@owned");

//更新白名单
Route::post("/user/apiip", "User/HandleController@apiip");

//下单购买 
Route::post("/user/order", "User/HandleController@order");

//用户注册
Route::post("/user/register", "User/HandleController@register");

//找回密码
Route::post("/user/forget", "User/HandleController@forget");

//用户登录
Route::post("/user/login", "User/HandleController@login");

//用户注销
Route::get("/user/logout", "User/HandleController@logout");

// 用户验证
Route::get("/user/auth/verify", "User/HandleController@authverify");

//修改密码
Route::post("/user/passwd", "User/HandleController@passwd");

// 卡密充值
Route::post("/user/recharge", "User/HandleController@kami");

#后台################################################

//后台登录页
Route::get("/KymKpFirRj4kBrLk/login.html", "Admin/IndexController@login");

//后台首页
Route::get("/KymKpFirRj4kBrLk", "Admin/IndexController@index");
Route::get('/KymKpFirRj4kBrLk' . '/', "Admin/IndexController@index");
Route::get("/KymKpFirRj4kBrLk/index.html", "Admin/IndexController@index");

Route::get("/KymKpFirRj4kBrLk/console.html", "Admin/IndexController@console");

//后台接口添加页
Route::get("/KymKpFirRj4kBrLk/addapi.html", "Admin/IndexController@addapi");

//后台接口添加页
Route::get("/KymKpFirRj4kBrLk/newkm.html", "Admin/IndexController@newkm");

//后台参数设置页
Route::get("/KymKpFirRj4kBrLk/apiinfo.html", "Admin/IndexController@apiinfo");

//后台数据绑定页
Route::get("/KymKpFirRj4kBrLk/datainfo.html", "Admin/IndexController@datainfo");

//后台文件绑定页
Route::get("/KymKpFirRj4kBrLk/fileinfo.html", "Admin/IndexController@fileinfo");

//后台接口编辑页
Route::get("/KymKpFirRj4kBrLk/editapi/{id}", "Admin/IndexController@editapi");

//后台接口列表页
Route::get("/KymKpFirRj4kBrLk/apilist.html", "Admin/IndexController@apilist");

//后台网站设置页
Route::get("/KymKpFirRj4kBrLk/webset.html", "Admin/IndexController@webset");

//后台会员列表页
Route::get("/KymKpFirRj4kBrLk/userinfo.html", "Admin/IndexController@userinfo");

//后台支付设置页
Route::get("/KymKpFirRj4kBrLk/payset.html", "Admin/IndexController@payset");

//后台退出登录
Route::get("/KymKpFirRj4kBrLk/logout", "Admin/IndexController@logout");

//后台密码修改
Route::get("/KymKpFirRj4kBrLk/passwd.html", "Admin/IndexController@passwd");

//后台用户编辑
Route::get("/KymKpFirRj4kBrLk/useredit/{id}", "Admin/IndexController@useredit");

//后台会员添加
Route::get("/KymKpFirRj4kBrLk/adduser.html", "Admin/IndexController@adduser");

// 注册设置
Route::get("/KymKpFirRj4kBrLk/setuser.html", "Admin/IndexController@setuser");

//后台邮箱配置
Route::get("/KymKpFirRj4kBrLk/email.html", "Admin/IndexController@email");

//redis配置
Route::get("/KymKpFirRj4kBrLk/redis.html", "Admin/IndexController@redis");

// 后台订单页
Route::get("/KymKpFirRj4kBrLk/order.html", "Admin/IndexController@order");

//添加卡密页
Route::get("/KymKpFirRj4kBrLk/addkami.html", "Admin/IndexController@addkami");

// 卡密管理页
Route::get("/KymKpFirRj4kBrLk/kami.html", "Admin/IndexController@kami");

#数据处理##########################################

//登录用户账号
Route::post("/KymKpFirRj4kBrLk/loginuser", "Admin/HandleController@loginuser");

// 添加卡密
Route::post("/KymKpFirRj4kBrLk/addkami", "Admin/HandleController@addkami");

//redis保存
Route::post("/KymKpFirRj4kBrLk/redis", "Admin/HandleController@redis");

//接口价格修改 
Route::post("/KymKpFirRj4kBrLk/charge", "Admin/HandleController@charge");

//添加用户
Route::post("/KymKpFirRj4kBrLk/adduser", "Admin/HandleController@adduser");

//邮箱配置
Route::post("/KymKpFirRj4kBrLk/email", "Admin/HandleController@email");

//修改登录密码
Route::post("/KymKpFirRj4kBrLk/passwd", "Admin/HandleController@passwd");

//会员编辑
Route::post("/KymKpFirRj4kBrLk/useredit", "Admin/HandleController@useredit");

//会员删除
Route::post("/KymKpFirRj4kBrLk/deluser", "Admin/HandleController@deluser");

//登录验证
Route::post("/KymKpFirRj4kBrLk/login", "Admin/HandleController@login");

//网站设置保存
Route::post("/KymKpFirRj4kBrLk/webset", "Admin/HandleController@webset");

// 注册设置
Route::post("/KymKpFirRj4kBrLk/setuser", "Admin/HandleController@setuser");

//支付设置保存
Route::post("/KymKpFirRj4kBrLk/payset", "Admin/HandleController@payset");

//接口添加
Route::post("/KymKpFirRj4kBrLk/addapi", "Admin/HandleController@addapi");

//获取表字段
Route::post("/KymKpFirRj4kBrLk/getField", "Admin/HandleController@getField");

//获取接口文件列表
Route::post("/KymKpFirRj4kBrLk/getApiFile", "Admin/HandleController@getApiFile");

// 获取接口文件内容 getApiFileC
Route::post("/KymKpFirRj4kBrLk/getApiFileC", "Admin/HandleController@getApiFileC");

// 接口文件上传 putApiFile
Route::post("/KymKpFirRj4kBrLk/putApiFile", "Admin/HandleController@putApiFile");

// 接口文件保存 editFile
Route::post("/KymKpFirRj4kBrLk/editFile", "Admin/HandleController@editFile");

//添加数据绑定
Route::post("/KymKpFirRj4kBrLk/datainfo", "Admin/HandleController@datainfo");

//删除接口
Route::post("/KymKpFirRj4kBrLk/delapi", "Admin/HandleController@delapi");

//添加参数绑定 
Route::post("/KymKpFirRj4kBrLk/apiinfo", "Admin/HandleController@apiinfo");

//删除参数
Route::post("/KymKpFirRj4kBrLk/delval", "Admin/HandleController@delval");

//获取参数
Route::post("/KymKpFirRj4kBrLk/getVal", "Admin/HandleController@getVal");

//修改接口
Route::post("/KymKpFirRj4kBrLk/editapi", "Admin/HandleController@editapi");


//欢迎页面
// Route::get("/welcome", "IndexController@welcome");

//测试页面
// Route::get("/dist", "IndexController@dist");

//图片上传接口
// Route::post('/uploads', "Common/CommonController@upload");
