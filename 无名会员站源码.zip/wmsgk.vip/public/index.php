<?php

error_reporting(E_ERROR);

//初始化
require __DIR__ . '/../app/init.php';
