<?php
return [
   "title" => '无名',
   "name" => '提供优质接口调用平台',
   "keywords" => '人口数据查询,泄露数据查询,查Q绑接口api,8亿q绑查询,Q绑8e数据库,8亿qq绑定数据查询,Q绑在线查询官网,查Q绑手机网页源码,查q绑,查地址,查q绑机器人,免费Q绑接口',
   "description" => '在线Q绑查询手机号官网 输入qq号即可查询 还支持反查 拥有16亿数据',
   "time" => '2021/02/14 18:00:00',
   "url1" => 'https://t.me/wmmsgkkfbot',
   "url2" => 'https://t.me/wmmsgk',
   "icp" => 'power by 无名',
   "about" => '<ul class="list-unstyled list-inline"><li>
    电子邮箱：admin@wmsgk.com
    </li><li>
    电报(tg)：<a href="https://t.me/wmmsgkkfbot">@wmmsgkkfbot</a><br>
    </li></ul>',
   "target" => 'webinfo',
];
?>