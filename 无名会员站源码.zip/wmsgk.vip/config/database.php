<?php
/*项目配置文件*/
return [
	'db' => 'mysql', 			//数据库类型
	'host' => 'localhost', 		//服务器地址
	'port' => '6603', 			//端口
	'user' => 'vipsite', 			//用户名
	'pass' => 'XDm7Zd73yt5B3yrs', 			//密码
	'charset' => 'utf8', 		//字符集
	'dbname' => 'vip'		//默认数据库
];
