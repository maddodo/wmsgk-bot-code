<?php
return [
   "mail_name" => '无名',
   "mail_smtp" => 'mail.wmsgk.com',
   "mail_port" => '25',
   "mail_user" => 'notice@wmsgk.com',
   "mail_pwd" => 'xP52PJYCzW5n7CHT',
];
