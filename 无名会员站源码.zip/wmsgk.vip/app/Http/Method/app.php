<?php
//自带定义操作方法
require __DIR__ . '/default.php';
//自定义操作方法
require __DIR__ . '/function.php';
//认证方法
require __DIR__ . '/Authentication.php';
