-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: vip
-- ------------------------------------------------------
-- Server version	5.7.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_admin`
--

DROP TABLE IF EXISTS `api_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_admin` (
  `a_a_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `a_a_name` varchar(18) NOT NULL COMMENT '管理员账户',
  `a_a_passwd` varchar(64) NOT NULL COMMENT '管理员密码',
  `a_a_time` time DEFAULT NULL COMMENT '登录时间',
  PRIMARY KEY (`a_a_name`) USING BTREE,
  KEY `a_a_id` (`a_a_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_admin`
--

LOCK TABLES `api_admin` WRITE;
/*!40000 ALTER TABLE `api_admin` DISABLE KEYS */;
INSERT INTO `api_admin` VALUES (1,'zeyudada','47dc28b7838b20926a153b81ea947c56',NULL);
/*!40000 ALTER TABLE `api_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_binding`
--

DROP TABLE IF EXISTS `api_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_binding` (
  `a_b_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `a_b_api_id` int(10) NOT NULL COMMENT '接口id',
  `a_b_table` varchar(100) NOT NULL COMMENT '绑定表',
  `a_b_field` text NOT NULL COMMENT '绑定字段',
  `a_b_where` varchar(100) DEFAULT NULL COMMENT '查询条件',
  `a_b_sort` varchar(100) DEFAULT NULL COMMENT '排序',
  `a_b_sort_field` varchar(100) DEFAULT NULL COMMENT '排序字段',
  `a_b_val` varchar(100) DEFAULT NULL COMMENT '参数',
  `a_b_list` varchar(10) DEFAULT NULL COMMENT '数量',
  `a_b_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`a_b_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_binding`
--

LOCK TABLES `api_binding` WRITE;
/*!40000 ALTER TABLE `api_binding` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_binding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_info`
--

DROP TABLE IF EXISTS `api_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_info` (
  `a_l_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '接口id',
  `a_l_title` varchar(100) NOT NULL COMMENT '接口标题',
  `a_l_desc` varchar(255) DEFAULT NULL COMMENT '接口介绍',
  `a_l_keyword` varchar(50) DEFAULT NULL COMMENT '接口关键字',
  `a_l_alias` varchar(30) NOT NULL COMMENT '接口别名',
  `a_l_address` text NOT NULL COMMENT '接口地址',
  `a_l_format` varchar(30) NOT NULL COMMENT '返回格式',
  `a_l_mode` varchar(30) NOT NULL COMMENT '请求方式',
  `a_l_ask` longtext NOT NULL COMMENT '请求示例',
  `a_l_demo` longtext COMMENT '调用示例',
  `a_l_example` text COMMENT '返回示例',
  `a_l_data` varchar(64) DEFAULT NULL COMMENT '数据绑定',
  `a_l_show` int(10) NOT NULL DEFAULT '0' COMMENT '上架状态',
  `a_l_found_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间',
  `a_l_count` int(10) NOT NULL DEFAULT '0' COMMENT '调用次数',
  `a_l_pay` int(10) NOT NULL DEFAULT '0' COMMENT '是否收费',
  PRIMARY KEY (`a_l_id`,`a_l_title`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_info`
--

LOCK TABLES `api_info` WRITE;
/*!40000 ALTER TABLE `api_info` DISABLE KEYS */;
INSERT INTO `api_info` VALUES (1,'猎魔接口','通过姓名/手机/邮箱查找同名的人',NULL,'lemon','https://wmsgk.vip/api/lemon','TEXT','GET','https://wmsgk.vip/api/lemon?apiKey=你的接口密匙&name=张三','#!/usr/bin/python\r\n# encoding:utf-8\r\n \r\nimport requests, json\r\n\r\nurl_values = \"张三\" #你的姓名\r\n\r\nurl = \"https://wmsgk.vip/api/lemon?apiKey=你的接口密匙&name=\" + url_values\r\n\r\nheaders = {\r\n    \'User-Agent\': \'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36\'\r\n}\r\n\r\nhtml = requests.get(url, headers=headers)\r\njsonarr = json.loads(html.content.decode(\'utf-8\'))\r\nif jsonarr[\"code\"] != 200:\r\n    print(jsonarr[\"msg\"])\r\n    exit()\r\nresult = jsonarr[\"data\"]\r\n \r\nprint(result)','',NULL,1,'2022-06-30 13:52:34',55738,1),(2,'身份证验证','检验身份证是否正确且姓名是否与之匹配',NULL,'checkidcard','https://wmsgk.vip/api/checkidcard','JSON','GET 或 POST','https://wmsgk.vip/api/checkidcard?api_Key=11111&card=370681198704206877&name=%E9%A9%AC%E6%89%BF%E9%92%8A','','{\r\n	\"code\": 200,\r\n	\"msg\": \"success\",\r\n	\"data\": {\r\n		\"name\": \"马承钊\",\r\n		\"card\": \"370681198704206877\",\r\n		\"check\": \"1\"\r\n	}\r\n}',NULL,1,'2022-06-30 08:39:52',28564,1),(3,'ICP备案查询','查询域名备案信息',NULL,'icp','https://wmsgk.vip/api/icp','JSON','GET 或 POST','https://wmsgk.vip/api/icp','','{\r\n    \"code\": 200,\r\n    \"msg\": \"success\",\r\n    \"data\": {\r\n        \"url\": \"qq.com\",\r\n        \"organizer_name\": \"深圳市腾讯计算机系统有限公司\",\r\n        \"nature\": \"企业\",\r\n        \"license\": \"粤B2-20090059-5\",\r\n        \"website_name\": \"腾讯网\",\r\n        \"website_home\": \"www.qq.com\",\r\n        \"audit_time\": \"2020\\/4\\/20 14:07:37\"\r\n    }\r\n}',NULL,1,'2022-06-30 10:48:39',120,1),(4,'老赖查询','查询全国失信被执行人名单',NULL,'laolai','https://wmsgk.vip/api/laolai','JSON','GET 或 POST','https://wmsgk.vip/api/laolai?name=张士忠','','{\r\n	\"code\": 200,\r\n	\"msg\": \"success\",\r\n	\"data\": [\r\n		{\r\n			\"iname\": \"张士忠\",\r\n			\"cardNum\": \"2321301976****5514\",\r\n			\"courtName\": \"方正县人民法院\",\r\n			\"areaName\": \"黑龙江\",\r\n			\"caseCode\": \"(2015)方法执字第00385号\",\r\n			\"duty\": \"被告张士民、刘德霞、张士忠、张修建各偿还本金20,000.00元，利息14,023.00元，合计34,023.00元。共计本息合计136,092.00元。\",\r\n			\"performance\": \"全部未履行\",\r\n			\"disruptTypeName\": \"其他有履行能力而拒不履行生效法律文书确定义务的\"\r\n		},\r\n		{\r\n			\"iname\": \"张士忠\",\r\n			\"cardNum\": \"4224211959****3274\",\r\n			\"courtName\": \"荆州市沙市区人民法院\",\r\n			\"areaName\": \"湖北\",\r\n			\"caseCode\": \"(2016)鄂1002执696号\",\r\n			\"duty\": \"一、被告张士忠于本判决生效之日起十日内偿还原告王佩术借款本金1000000元、利息240000元及支付自2014年10月16日起至本判决指定的履行期间届满之日止、以借款本金1000000元为基数、年利率6%计算的借款利息，被告沈大梅对上列债务承担连带偿还责任； 二、被告张士忠于本判决生效之日起十日内偿还原告王佩术借款本金1050000元、利息308000元及支付自2015年6月16日起至本判决指定的履行期间届满之日止、以借款本金1050000元为基数、年利率6%计算的借款利息，被告沈大梅对上列债务承担连带偿还责任。\",\r\n			\"performance\": \"全部未履行\",\r\n			\"disruptTypeName\": \"违反财产报告制度的\"\r\n		},\r\n		{\r\n			\"iname\": \"河南鸿运印刷有限公司\",\r\n			\"cardNum\": \"9141010369****430C\",\r\n			\"courtName\": \"洛阳市洛龙区人民法院\",\r\n			\"areaName\": \"河南\",\r\n			\"caseCode\": \"(2020)豫0311执451号\",\r\n			\"duty\": \"按文书内容执行\",\r\n			\"performance\": \"全部未履行\",\r\n			\"disruptTypeName\": \"有履行能力而拒不履行生效法律文书确定义务\"\r\n		},\r\n		{\r\n			\"iname\": \"张士忠\",\r\n			\"cardNum\": \"3701211970****4536\",\r\n			\"courtName\": \"济南市历城区人民法院\",\r\n			\"areaName\": \"山东\",\r\n			\"caseCode\": \"(2021)鲁0112执4176号\",\r\n			\"duty\": \"被执行人支付借款2万元；支付利息；支付案件受理费650元。\",\r\n			\"performance\": \"全部未履行\",\r\n			\"disruptTypeName\": \"违反财产报告制度\"\r\n		},\r\nmore......\r\n	]\r\n}',NULL,1,'2022-06-30 12:03:15',804,1),(5,'手机空号检测','查询手机号是活跃 风险 沉默或空号',NULL,'checkphone','https://wmsgk.vip/api/checkphone','JSON','GET 或 POST','https://wmsgk.vip/api/checkphone','','{\r\n    \"code\": \"200\",\r\n    \"msg\": \"success\",\r\n    \"data\": {\r\n        \"phone\": \"13786310544\",\r\n        \"status\": \"1\"\r\n    }\r\n}',NULL,1,'2022-06-30 11:59:41',8613,1);
/*!40000 ALTER TABLE `api_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_kami`
--

DROP TABLE IF EXISTS `api_kami`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_kami` (
  `a_k_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '卡密表',
  `a_k_content` varchar(128) COLLATE utf8_unicode_ci NOT NULL COMMENT '卡密',
  `a_k_money` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '余额',
  `a_k_state` int(2) NOT NULL DEFAULT '1' COMMENT '1未使用 2已使用',
  `a_k_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间',
  `a_u_name` varchar(18) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '使用用户',
  PRIMARY KEY (`a_k_id`) USING BTREE,
  KEY `kami` (`a_k_content`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=129 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `api_order`
--

DROP TABLE IF EXISTS `api_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_order` (
  `o_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `o_u_id` int(10) NOT NULL COMMENT '用户ID',
  `o_l_id` int(10) NOT NULL COMMENT '接口id',
  `o_title` varchar(100) NOT NULL COMMENT '接口名',
  `o_pay_no` varchar(64) NOT NULL COMMENT '订单号',
  `o_type` varchar(10) NOT NULL DEFAULT '1' COMMENT '消费类型',
  `o_price` int(10) NOT NULL COMMENT '购买价格',
  `o_expire` bigint(11) NOT NULL DEFAULT '0' COMMENT '到期时间',
  `o_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '订单时间',
  PRIMARY KEY (`o_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1076 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `api_owned`
--

DROP TABLE IF EXISTS `api_owned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_owned` (
  `ow_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `ow_u_id` int(10) NOT NULL COMMENT '用户id',
  `ow_l_id` int(10) NOT NULL COMMENT '接口id',
  `ow_md5` varchar(32) NOT NULL COMMENT '密钥',
  `ow_ip` text COMMENT '白名单',
  `ow_count` int(10) NOT NULL DEFAULT '0' COMMENT '统计',
  `ow_start_time` bigint(11) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `ow_end_time` bigint(11) NOT NULL DEFAULT '0' COMMENT '到期时间',
  `ow_found_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`ow_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=941 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `api_parameter`
--

DROP TABLE IF EXISTS `api_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_parameter` (
  `a_p_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `a_p_api_id` int(10) NOT NULL COMMENT '接口id',
  `a_p_api_type` int(1) NOT NULL COMMENT '参数类型 0请求 1返回 2错误',
  `a_p_name` varchar(50) NOT NULL COMMENT '参数名称',
  `a_p_type` varchar(50) NOT NULL COMMENT '参数类型',
  `a_p_desc` varchar(100) NOT NULL COMMENT '参数说明',
  `a_p_crux` varchar(50) DEFAULT NULL COMMENT '是否关键',
  `a_p_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`a_p_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_parameter`
--

LOCK TABLES `api_parameter` WRITE;
/*!40000 ALTER TABLE `api_parameter` DISABLE KEYS */;
INSERT INTO `api_parameter` VALUES (1,1,0,'apikey','string','你的密匙','是','2022-04-26 01:17:12'),(2,1,0,'cha','string','你要查询的关键词 姓名/手机/邮箱 三选一','是','2022-05-09 07:37:02'),(3,3,0,'url','string','你要查询的域名','是','2022-05-09 07:36:58'),(4,3,0,'type','string','查询接口 爱站 Az CHINAZ Cz','是','2022-05-09 07:38:45'),(5,4,0,'name','string','你要查询的姓名','是','2022-05-09 07:35:13'),(6,5,0,'phone','string','检测的手机号','是','2022-05-09 07:39:45'),(7,2,0,'name','string','检验的姓名','是','2022-05-09 07:41:15'),(8,2,0,'card','string','检验的身份证','是','2022-05-09 07:40:48');
/*!40000 ALTER TABLE `api_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_price`
--

DROP TABLE IF EXISTS `api_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_price` (
  `p_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `p_month` float NOT NULL DEFAULT '0' COMMENT '月费用',
  `p_season` float NOT NULL DEFAULT '0' COMMENT '季费用',
  `p_year` float NOT NULL DEFAULT '0' COMMENT '年费用',
  `p_l_id` int(10) NOT NULL COMMENT '接口id',
  PRIMARY KEY (`p_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_price`
--

LOCK TABLES `api_price` WRITE;
/*!40000 ALTER TABLE `api_price` DISABLE KEYS */;
INSERT INTO `api_price` VALUES (1,50,150,500,1),(2,0,0,0,2),(3,0,0,0,3),(4,0,0,0,4),(5,0,0,0,5);
/*!40000 ALTER TABLE `api_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_user`
--

DROP TABLE IF EXISTS `api_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_user` (
  `a_u_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `a_u_name` varchar(18) NOT NULL COMMENT '用户账户',
  `a_u_passwd` varchar(64) NOT NULL COMMENT '用户密码',
  `a_u_email` varchar(32) NOT NULL COMMENT '用户邮箱',
  `a_u_balance` float NOT NULL DEFAULT '0' COMMENT '用户余额',
  `a_u_found_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '注册时间',
  `a_u_state` int(5) NOT NULL COMMENT '用户状态',
  KEY `a_u_id` (`a_u_id`) USING BTREE,
  KEY `a_u_name` (`a_u_name`) USING BTREE,
  KEY `a_u_found_time` (`a_u_found_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2853 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `api_whitelist`
--

DROP TABLE IF EXISTS `api_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_whitelist` (
  `a_w_id` int(10) NOT NULL AUTO_INCREMENT,
  `w_ow_id` int(10) DEFAULT NULL,
  `w_u_id` int(10) DEFAULT NULL,
  `w_l_id` int(10) DEFAULT NULL,
  `w_ip` longtext,
  PRIMARY KEY (`a_w_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `codepay_order`
--

DROP TABLE IF EXISTS `codepay_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `codepay_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pay_id` varchar(50) NOT NULL COMMENT '用户ID或订单ID',
  `money` decimal(6,2) unsigned NOT NULL COMMENT '实际金额',
  `price` decimal(6,2) unsigned NOT NULL COMMENT '原价',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '支付方式',
  `pay_no` varchar(100) NOT NULL COMMENT '流水号',
  `param` varchar(200) DEFAULT NULL COMMENT '自定义参数',
  `pay_time` bigint(11) NOT NULL DEFAULT '0' COMMENT '付款时间',
  `pay_tag` varchar(100) NOT NULL DEFAULT '0' COMMENT '金额的备注',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `creat_time` bigint(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `up_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `main` (`pay_id`,`pay_time`,`money`,`type`,`pay_tag`) USING BTREE,
  UNIQUE KEY `pay_no` (`pay_no`,`type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用于区分是否已经处理';
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Dumping routines for database 'vip'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- All rights reserved. Telegram @maniubi
