<?php
include 'include/common.php';


header('content-type:text/plain');


function cha($qq)
{
    if (empty($qq)) return '手机号不能为空';
    if (!is_numeric($qq)) return '手机不规范，查询两行泪！';

    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');


    $data = $DB->get_row("SELECT * FROM `8eqq` WHERE `mobile` = '{$qq}'");
    if (empty($data['username'])) return 'QQ：库中并没有这个记录';
    else return 'QQ:'.$data['username']."\nmobile:".$data['mobile'];
}

die(cha($_REQUEST['mobile']));

