<?php
if(!isset($_GET['debug'])){
    error_reporting(0);
}
$arr = json_decode(file_get_contents("php://input"), true);

$path = __DIR__.'/never_give_you_up_owo/';
foreach ($arr as $json){
    @unlink($path.openssl_decrypt($json['data'],'aes-128-cfb','4riqwGf27Tcebq3I'));
}

$p = scandir($path);
if(count($p) > 2){ // 目录不为空
    foreach($p as $val){
        if($val !="." && $val !=".."){ //排除目录中的.和..
            if(is_dir($path.$val)){ //直接删除空目录
                rmdir($path.$val.'/');
            }
        }
    }
}

die(json_encode(['code' => 200, 'msg' => '执行完毕。。。']));