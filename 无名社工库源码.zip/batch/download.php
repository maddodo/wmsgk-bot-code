<?php
if(!isset($_GET['debug'])){
    error_reporting(0);
}
if(empty($_GET['key'])){
    header('HTTP/1.1 404 Not Found');
    die();
}
$filename = openssl_decrypt($_GET['key'],'aes-128-cfb','Ly7zK2cTAbmtLyZK');
$file = __DIR__.'/never_give_you_up_owo/'.$filename;
if(!file_exists($file)){
    header('HTTP/1.1 404 Not Found');
    die();
}else{
    header('Content-Type: application/octet-stream');
$filesize = filesize($file);
header('Content-Transfer-Encoding: binary');
header('Content-Encoding: none');
header('Content-type: application/force-download');
header('Content-length: '.$filesize);
header('Content-Disposition: attachment; filename="'.time().'.csv"');
readfile($file);
}
