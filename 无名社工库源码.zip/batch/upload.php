<?php
/*
 * @Author: zeyudada
 * @Date: 2022-03-18 18:57:12
 * @LastEditTime: 2022-03-18 19:03:48
 * @Description: 批量查Q绑
 * @Q Q: zeyunb@vip.qq.com(1776299529)
 * @E-mail: admin@zeyudada.cn
 * 
 * Copyright (c) 2022 by zeyudada, All Rights Reserved. 
 */


if (!isset($_GET['lbwnbdebug'])) error_reporting(0);

header("Access-Control-Allow-Methods:POST");
header('Content-type:application/json');

$ip = $_SERVER['HTTP_CF_CONNECTING_IP'];

if (empty($_FILES['file'])) json(['code' => 201, 'msg' => '请选择文件后上传！']);
if ($_FILES['file']['type'] != 'text/plain') json(['code' => 201, 'msg' => '请选择TXT文件！']);
if ($_FILES['file']['error'] > 0) json(['code' => 500, 'msg' => '上传时遇到错误 请刷新后重试']);
if ($_FILES['file']['size'] > (1024 * 25)) json(['code' => 201, 'msg' => '文件过大 请选择25KB以下的文件']);

function json(array $json)
{
    die(json_encode($json));
}

$text = file_get_contents($_FILES['file']['tmp_name']);

if (strpos($text, "\r\n") !== false) $line = "\r\n";
else if (strpos($text, "\n") !== false) $line = "\n";
else json(['code' => 201, 'msg' => '无法检测您的文件里的换行符']);

$qqs = explode($line, $text);

if (count($qqs) > 2000) json(['code' => 201, 'msg' => '数量超过2000！']);

header('Content-type: application/json');

require_once('./db.class.php');
$DB = new DB('localhost', 'bind', 'dZGk42XcYNyCSyBm', 'bind', 3306);

function cha($qq)
{
    global $DB;
    //global $pl;
    if (empty($qq)){
        $GLOBALS['data'] .= $qq . ',QQ为空, ';
        return false;
    }

    if (!is_numeric($qq)) {
        $GLOBALS['data'] .=  $qq . ',格式不对, ';
        return false;
    }


    $data = $DB->get_row("SELECT * FROM `8eqq` WHERE `username` = '{$qq}'");
    if ($data['username'] == '') {
        $GLOBALS['data'] .=  $qq . ',无结果, ';
    } else {
        //$pl = new PhoneLocation();
        //$place = $pl->find($data["mobile"]);
        $GLOBALS['data'] .= $data['username'] . ',' . $data['mobile'] . ',' . implode(' ', phone($data["mobile"]));
    }
}

$GLOBALS['data'] = "QQ,查询结果,归属地\n";
foreach ($qqs as $qq) {
    cha($qq);
    $GLOBALS['data'] .=  "\n";
}

$filename = $ip . '/' . date('Y-m-d H:i:s') . '_' . rand() . '.csv';

if (!is_dir($ip)){
    mkdir (__DIR__ . '/never_give_you_up_owo/' .$ip,0744,true);
}
//file_put_contents('./never_give_you_up_owo/'.$filename, $GLOBALS['data']);
fwrite(fopen(__DIR__ . '/never_give_you_up_owo/' . $filename, 'w'), iconv("UTF-8", "gb2312//IGNORE", $GLOBALS['data']));

json(['code' => 0, 'msg' => '查询成功！', 'name'=>$_FILES['file']['name'], 'time' => date('Y-m-d H:i:s'), 'data' => openssl_encrypt($filename, 'aes-128-cfb', 'Ly7zK2cTAbmtLyZK')]);
