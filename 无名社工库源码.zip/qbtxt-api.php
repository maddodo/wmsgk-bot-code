<?php
include_once 'include/common.php';


header('content-type:text/plain');


function cha($qq)
{

    if (empty($qq)) return "QQ不能为空\n";
    if (!is_numeric($qq)) return "QQ不规范，查询两行泪！\n";

    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');
    
    $data = $DB->get_row("SELECT * FROM `8eqq` WHERE `username` = '{$qq}'");
  if (empty($data['username'])) return "库中并没有这个记录\n";
  else return 'QQ:'.$data['username']."\nmobile:".$data['mobile']."\nplace:".implode(' ', phone($data['mobile']));

}



die(cha($_REQUEST["qq"]));

