<?php
include 'include/common.php';


header('content-type:text/plain');


function cha($qq)
{
    if (empty($qq)) return '昵称不能为空';

    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');


    $data = $DB->get_row("SELECT * FROM `lol` WHERE `name` = '{$qq}'");
    if (empty($data['name'])) return '库中并没有这个记录';
    else return 'QQ:'.$data['qq']."\nname:".$data['name']."\nserver:".$data['sever']."\n";
}

die(cha($_REQUEST['name']));
