<!DOCTYPE html>
<html lang="zh-cn">

<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
	<link rel="shortcut icon" href="//8zyw.cn/favicon.ico" type="image/x-icon">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>广告加载中，请稍后......</title>
	<link href="//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<style>
		body { width: 100%; height: 100vh } .main { position: relative; width: 100%; height: 100%; background: #000; display: flex; justify-content: center; align-items: center } .circle { display: flex; justify-content: center; align-items: center; width: 200px; height: 200px; background-image: linear-gradient(0deg, #2f66ff, #9940ff 30%, #ee37ff 60%, #ff004c 100%); border-radius: 50%; animation: rotate 1s linear infinite } .circle::before { content: ""; position: absolute; width: 200px; height: 200px; background-image: linear-gradient(0deg, #2f66ff, #9940ff 30%, #ee37ff 60%, #ff004c 100%); border-radius: 50%; filter: blur(35px) } .circle::after { content: ""; position: absolute; width: 150px; height: 150px; background: #000; border-radius: 50% } h1 { position: absolute; color: #fff; font-weight: 700 } .title { color: #fff; position: absolute; top: 10%; text-shadow: 0 0 30px #fff; text-align: center; font-size: 2rem; font-weight: 700 } .text { color: #fff; position: absolute; bottom: 10%; text-shadow: 0 0 30px #fff; font-weight: 700; text-align: center } @keyframes rotate { 0% { transform: rotate(0) } 100% { transform: rotate(360deg) } }
	</style>
</head>

<body onload="time()">
	<div class="main">
		<div class="circle"></div>
		<h1 id="second">3s</h1>
		<p class="title">广告加载中，请稍后......</p>
		<p class="text">网络交易请谨慎自行甄别 如遇欺诈或纠纷 请联系我们的TG @wmsgkkfbot 投诉下架该广告</p>
	</div>
</body>
<script>
	function cs() {
		var query = "<?php echo ($_GET['url']); ?>";
		if (query != "") {
			return query;
		}

		return ("http://t.me/wmsgkkfbot"); //无指定跳转地址，将跳转此网页地址。
	}

	function time() {
		var sec = document.getElementById("second");
		var i = 3; //设置定时时间
		var timer = setInterval(function() {
			i--;
			sec.innerHTML = i + "s";
			if (i == 1) {
				window.location.href = cs();
			}
		}, 1000);

		function goBack() {
			window.history.go(-1);
		}
	}
</script>

</html>