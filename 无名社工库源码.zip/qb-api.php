<?php
include 'include/common.php';
//加个text返回


header('content-type:application/json');

function cha($qq)
{
	global $gg;
    if (empty($qq)) return ['code' => 201, 'msg' => 'QQ不能为空'];

    if (!is_numeric($qq)) return ['code' => 203, 'msg' => 'QQ不规范，查询两行泪！'];
    
    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');


    $data = $DB->get_row("SELECT * FROM `8eqq` WHERE `username` = '{$qq}'");
    if (empty($data['username'])) return ['code' => 202, 'qq' => $qq, 'msg' => '库中并没有这个记录！'];
    else return [
            'code' => 200,
            'msg' => 'ok',
            'data' => [
                'qq' => $data['username'],
                'mobile' => $data['mobile']
            ],
            'place' => phone($data['mobile']),
            'tips' => $gg
        ];
}



if (!empty($_REQUEST['qq'])) die(json_encode(cha($_REQUEST["qq"])));

