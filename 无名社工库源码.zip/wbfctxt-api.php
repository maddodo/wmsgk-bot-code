<?php
include 'include/common.php';

header('content-type:text/plain');

function cha($uid)
{

    if (empty($uid)) return "手机不能为空";
    if (!is_numeric($uid)) return "手机不规范，查询两行泪！";

    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');

    if ($DB->get_row("SELECT *  FROM `weibo` WHERE `uid` = '{$uid}'")) return "微博：库中并没有这个记录。";


    $data = $DB->get_row("SELECT * FROM `weibo` WHERE `mobile` = '{$uid}'");
    if (empty($data['uid'])) return "库中并没有这个记录！";
    else return ("uid:" . $data['uid'] . "\nmobile:" . $data['mobile']);
}

die(cha($_REQUEST["mobile"]));
