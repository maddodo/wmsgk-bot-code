<?php
include 'include/common.php';

header('content-type:application/json');

if (empty($_REQUEST['mobile'])) $result = ['code' => 201, 'msg' => '手机号不能为空'];
elseif (!is_numeric($_REQUEST['mobile']) || strlen($_REQUEST['mobile']) != 11) $result = ['code' => 203, 'msg' => '手机不规范，查询两行泪！'];
else $result = [
    'code' => 200,
    'msg' => 'ok',
    'place' => phone($_REQUEST['mobile']),
    'tips' => $gg
];


die(json_encode($result));
