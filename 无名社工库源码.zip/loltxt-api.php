<?php
include_once 'include/common.php';


header('content-type:text/plain');


function cha($qq)
{

  if (empty($qq)) return "QQ不能为空\n";
  if (!is_numeric($qq)) return "QQ不规范，查询两行泪！\n";

  $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');

  $data = $DB->get_row("SELECT * FROM `lol` WHERE `qq` = '{$qq}'");
  if (empty($data['name'])) return "库中并没有这个记录\n";
  else return 'QQ:' . $data['qq'] . "\nname:" . $data['name'] . "\nserver:" . $data['sever'] . "\n";
}


  echo (cha($qq));
  