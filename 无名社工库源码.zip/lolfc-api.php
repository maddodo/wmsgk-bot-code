<?php
include 'include/common.php';


header('content-type:application/json');


function cha($qq)
{
	global $gg;
    if (empty($qq)) return ['code' => 201, 'msg' => '昵称不能为空'];

    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');


    $data = $DB->get_row("SELECT * FROM `lol` WHERE `name` = '{$qq}'");
    if (empty($data['name'])) return ['code' => 202, 'qq' => $qq, 'msg' => '库中并没有这个记录！'];
    
    else return [
            'code' => 200,
            'msg' => 'ok',
            'data' => $data,
            'tips' => $gg
        ];
}


if (!EASY) die(json_encode(cha($_REQUEST["name"])));

