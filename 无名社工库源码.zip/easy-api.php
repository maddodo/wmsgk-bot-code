<?php
if(!isset($_GET['lbwnbdebug'])) error_reporting(0);

define('EASY', true);

$yyy = ($_GET['yyy'] == 'on') ? '' : 'fc';

switch ($_REQUEST['mode']) {
    case 'qb':
        include('qb'.$yyy.'-api.php');
        break;

    case 'wb':
        include('wb'.$yyy.'-api.php');
        break;

    case 'lol':
        include('lol'.$yyy.'-api.php');
        break;
    
    default:
        die(json_encode(['code' => 203, 'msg' => '查询模式不存在！']));
        break;
}

die(json_encode(cha($_REQUEST['account'])));
