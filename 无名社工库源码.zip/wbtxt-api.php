<?php
include 'include/common.php';


header('content-type:text/plain');


function cha($uid)
{
    if (empty($uid)) return "uid不能为空";

    if (!is_numeric($uid)) return "uid不规范，查询两行泪！";

    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');


    $data = $DB->get_row("SELECT * FROM `weibo` WHERE `uid` = '{$uid}'");
    if (empty($data)) return "库中并没有这个记录！";
    else return "uid:".$data['uid']."\nmobile".$data['mobile']."\nlocation:".implode(' ', phone($data['mobile']));
    
}

die(cha($_REQUEST["uid"]));

