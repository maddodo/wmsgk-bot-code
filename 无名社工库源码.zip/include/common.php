<?php
header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Methods:GET,POST");

if(!isset($_GET['lbwnbdebug'])) error_reporting(0);

$gg = "官网wmsgk.com 电报@wmsgk";

require_once('db.class.php');

function getIP() {
	/*
    if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } else if (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } else if (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $res =  preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';*/
    
    return $_SERVER['HTTP_CF_CONNECTING_IP'];
    // 用户的国家代码，例如 CN, EN, CA 等
    $country = $_SERVER["HTTP_CF_IPCOUNTRY"];
}



/*
function weblocation($mobile){
    //第一种
    $txt = file_get_contents("https://www.sogou.com/websearch/phoneAddress.jsp?phoneNumber=". $mobile);
    preg_match('/void\("(.*)"\);/',$txt,phone($data['mobile']));
    phone($data['mobile']) = mb_convert_encoding(phone($data['mobile'])[1], 'UTF-8', "GB2312");
    /*第二种
   $host = "https://jshmgsdmfb.market.alicloudapi.com";
    $path = "/shouji/query";
    $method = "GET";
    $appcode = "4b59326b6bbf4873a88b2f78f5756c44";
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "shouji=".$data['mobile'];
    $bodys = "";
    $url = $host . $path . "?" . $querys;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);

    if (1 == strpos("$".$host, "https://"))
    {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }
    phone($data['mobile']) = json_decode(curl_exec($curl),true);
    if(phone($data['mobile'])["status"]==0){
    phone($data['mobile']) = phone($data['mobile'])["result"];
    }else if(phone($data['mobile'])["status"]==201){
    phone($data['mobile']) = "手机号为空？系统错误！";
    }else if(phone($data['mobile'])["status"]==202){
    phone($data['mobile']) = "手机号不正确，可能数据太旧";
    }else if(phone($data['mobile'])["status"]==203){
    phone($data['mobile']) = "没有查询到归属结果";
    }else{
    phone($data['mobile']) = "查询超时或者次数满了";
    }
    return phone($data['mobile']);
}

/*停用授权功能，多此一举
function get_host($to_virify_url = ''){
    
    $url   = $to_virify_url ? $to_virify_url : $_SERVER['HTTP_HOST'];
    $data = explode('.', $url);
    $co_ta = count($data);
 
    //判断是否是双后缀
    $zi_tow = true;
    $host_cn = 'com.cn,net.cn,org.cn,gov.cn';
    $host_cn = explode(',', $host_cn);
    foreach($host_cn as $host){
        if(strpos($url,$host)){
            $zi_tow = false;
        }
    }
 
    //如果是返回FALSE ，如果不是返回true
    if($zi_tow == true){
 
        // 是否为当前域名
        if($url == 'localhost'){
            $host = $data[$co_ta-1];
        }
        else{
            $host = $data[$co_ta-2].'.'.$data[$co_ta-1];
        }
        
    }
    else{
        $host = $data[$co_ta-3].'.'.$data[$co_ta-2].'.'.$data[$co_ta-1];
    }
    
    return $host;
}

$host = get_host();
//var_dump($host);
if($host=="fulimcp.cn"){
die(json_encode(["code"=>201,"msg"=>"【重要公告】new.fulimcp域名改为任意.tzact.com，并且api.cjsrcw域名停用。详情电报联系@maniubi"]));
}else{
session_start();
if($_SESSION[$host] > time()) {
letmecha();
}else{
//检验授权

	$query=file_get_contents('http://65.49.203.28:2333/urlcheck.php?url='.$host);

	if($query=json_decode($query,true)) {
		if($query['code']==1){
$_SESSION[$host]=$query['time'];
letmecha();
		}else{
	 echo('<h3>'.$query['msg'].'</h3>');
	 }
	}else{
	die(json_encode(["code"=>201,"msg"=>"授权服务器崩了。。。请稍等再查"]));
	}
}
}
*/


