<?php
/*
 * @Author: zeyudada
 * @Date: 2022-04-19 16:47:31
 * @LastEditTime: 2022-04-20 08:42:02
 * @Description: 
 * @Q Q: zeyunb@vip.qq.com(1776299529)
 * @E-mail: admin@zeyudada.cn
 * 
 * Copyright (c) 2022 by zeyudada, All Rights Reserved. 
 */
include 'include/common.php';


header('content-type:application/json');


function cha($uid)
{
    global $gg;

    if (empty($uid)) return ['code' => 201, 'msg' => '手机不能为空'];
    if (!is_numeric($uid)) return ['code' => 203, 'msg' => '手机不规范，查询两行泪！'];

    $DB = new DB('bind', 'dZGk42XcYNyCSyBm', 'bind');

    if ($DB->get_row("SELECT *  FROM `weibo` WHERE `uid` = '{$uid}'")) return ['code' => 202, 'msg' => '库中并没有这个记录。'];


    $data = $DB->get_row("SELECT * FROM `weibo` WHERE `mobile` = '{$uid}'");
    if (empty($data['uid'])) return ['code' => 202, 'uid' => $uid, 'msg' => '库中并没有这个记录！'];
    else return [
            'code' => 200,
            'msg' => 'ok',
            'data' => [
                'uid' => $data['uid'],
                'mobile' => $data['mobile']
            ],
            'tips' => $gg
        ];
}


if (!EASY) die(json_encode(cha($_REQUEST["mobile"])));

