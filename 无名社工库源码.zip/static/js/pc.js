var ads = '<table><tbody id="imgs"><tbody><tr><td><a href="https://wmsgk.com/url.php?url=http%3A%2F%2Fqb-api.cc"target="_blank"><img src="//ae01.alicdn.com/kf/U04dd46e33f78453694f538ebe9d1d76bS.jpg"style="width:100%"></a></td><td><img src="//ae01.alicdn.com/kf/U14802a4d3968437e8d18814fb126849cL.jpg"style="width:100%"></td></tr><tr><td><a href="https://wmsgk.com/url.php?url=http%3A%2F%2Fwww.52x1.cn"target="_blank"alt="7.25"><img src="//ae01.alicdn.com/kf/Ucdaf8165ce43491681d63dc26ecf5d75l.jpg"style="width:100%"></a></td><td><a href="https://wmsgk.com/url.php?url=http%3A%2F%2Fxk115.cn"target="_blank"><img src="//ae01.alicdn.com/kf/U13aa4ee1de0d44cbac0afc8f7cf6f9994.jpg"style="width:100%"></a></td></tr><tr><td><a href="https://wmsgk.com/url.php?url=http%3A%2F%2Fdsw6.cn"target="_blank"><img src="//cdn.u1.huluxia.com/g4/M03/E3/ED/rBAAdmDW-pOAN84WAAAXxDvVZf4443.png"style="width:100%"alt="7.26"></a></td><td><a href="https://wmsgk.com/url.php?url=http%3A%2F%2Fsl.gb4399.cn"target="_blank"alt="7.13"><img src="//ae01.alicdn.com/kf/U6366e6dbe74f4dbe8170ac5cc9c6c828h.jpg"style="width:100%"></a></td></tr><tr><td><a href="https://wmsgk.com/url.php?url=http%3A%2F%2Fdh.gstd888.cn"target="_blank"><img src="//i.niupic.com/images/2021/05/31/9jUy.jpg"style="width:100%"alt="6.29"></a></td><td><a href="https://wmsgk.com/url.php?url=http%3A%2F%2Fkg.kamic.xyz"target="_blank" alt="7.4"><img src="//i.niupic.com/images/2021/06/04/9kgk.png"style="width:100%"></a></td></tr></tbody></tbody></table>';


function cha(mod, cs) {
    var qq = $('#input').val()
    if (qq == '') {
        var alert_1 = layer.msg('请输入查询信息', {
            icon: 5
        });
    } else {

        layer.confirm('<b style="color:#ff4425">仅供查询自己的的账号，不是自己的请立即退出本页面，否则发生的一切后果站长不负责！</b>', {
            btn: ['确认', '取消'] //按钮
        }, function () {
            layer.close(layer.index);
            var alert_1 = layer.load(0, {
                shade: 0.5
            });
            $url = '/' + mod + '-api.php?mod=cha&' + cs + '=' + qq;

            $.getJSON($url, function (json) {
                layer.close(alert_1);
                if (json['code'] == 200 && json['msg'] == 'ok') {
                    layer.msg('<b style="color:#ff4425">无名社工库提醒您：查询成功</b>', {
                        icon: 1
                    });
                    $('#mobile').val(json['data']['mobile'])
                    if (qq == '') {
                        $('#place').val("空")
                    } else {
                        $('#place').val(json['place']['province'] + json['place']['city'] + json['place']['sp'])
                    }
                    $('#jiexi_data').css("display", "block");
                } else {
                    layer.msg(json['msg']);
                    $('#jiexi_data').css("display", "none");
                }
            });
        }, function () {
            return
        });

    }
}

function jiabai(mod, cs) {
    console.log(mod)
    layer.close(layer.index)
    var qq = $('#input').val()
    if (qq == '') {
        var alert_1 = layer.msg('请输入查询信息', {
            icon: 5
        });
    } else {
        layer.prompt({
            title: '请输入加白密匙',
            formType: 1
        }, function (key, index) {
            layer.close(index);
            $url = mod + '-api.php?mod=jiabai&key=' + key + '&qq=' + qq
            var alert_1 = layer.load(0, {
                shade: 0.5
            })
            $.getJSON($url, function (json) {
                layer.close(alert_1)
                console.log(json)
                if (json['code'] == 0) {
                    layer.msg('加白成功！', {
                        icon: 1
                    })
                } else {
                    layer.msg('加白失败！' + json['msg'], {
                        icon: 5
                    })
                }

            });
        });

    }
}

function lol($mod) {
    var qq = $('#uid').val()
    if (qq == '') {
        var alert_1 = layer.msg('请输入QQ', {
            icon: 5
        })
    } else {

        if ($mod == 'cha') {
            dialog('<div style="text-align:center"><br><b style="color:#ff4425">仅供查询自己的微博<br>不是自己的请立即退出本页面<br>否则发生的一切后果站长不负责<br><br>确认查询？？</b><br><br><a onclick=' + 'lolcha("cha")' + ' class="btn btn-block btn-primary" style="background: linear-gradient(to right,#b221ff,#14b7ff)">确认</a><br></div>', 1)
        } else {
            dialog('<div style="text-align:center"><div class="list-group-item list-group-item-info" style="font-weight: bold"><input class="form-control" id="key" placeholder="请输入key"></div><b style="color:#ff4425">加白只是在本站无法查找，并不代表全网，请知悉<a onclick=' + 'lolcha("jiabai")' + ' class="btn btn-block btn-primary" style="background: linear-gradient(to right,#b221ff,#14b7ff)">加白</a><br></div>', 1)
        }

    }
}

function lolcha(mod) {
    console.log(mod)
    layer.close(layer.index)
    var qq = $('#uid').val()
    if (mod == 'cha') {
        $url = 'lol-api.php?mod=cha&qq=' + qq
    } else {
        var key = $('#key').val()
        $url = 'lol-api.php?mod=jiabai&key=' + key + '&qq=' + qq
    }

    var alert_1 = layer.load(0, {
        shade: false
    })
    $.getJSON($url, function (json) {
        layer.close(alert_1)
        console.log(json)
        if (json['code'] == 200 && json['msg'] == 'ok') {
            layer.msg('查询成功', {
                icon: 1
            })
            $('#name').val(json['data']['name'])
            $('#server').val(json['data']['server'])
            $('#loljiexi_data').css("display", "block")
        } else {
            layer.msg(json['msg'])
            $('#loljiexi_data').css("display", "none")
        }
    });
}

function dialog(code, exit) {
    layer.open({
        type: 1,
        skin: 'layui-layer-lan', //加上边框
        area: ['90%', ''], //宽高
        closeBtn: exit,
        shadeClose: true,
        shade: 0.8,
        title: '提示',
        btnAlign: 'c',
        content: code,
    });
}


function changeColor() {
    var color = "red|green|blue|black";
    color = color.split("|");
    document.getElementById("wy").style.color = color[parseInt

        (Math.random() * color.length)];
}

function gg() {
    layer.confirm('您好！欢迎来到查绑API！本站目前是全网最大的泄露信息查询API！<br>人口接口稳定使用，目前拥有3.7亿人口库！同行最低价！点击下方跳转会员站或者在网站底部跳转<br><font color="#FF0000">本页已经把所有开放信息都写上了，建议从头到尾看一遍！广告也不例外！</font><br><b>收藏本站不迷路！</b><br>●API文档界面更新啦！（其实其他同行的API文档界面都是直接扒的我们的）<br><a onclick="law()"●点我围观：真假律师函</a>', {
        btn: ['跳转会员站', '添加桌面快捷方式'],
        title: '公告',
        shadeClose: true
    }, function () {
        layer.msg('需要注册登录才能购买接口哦！', {
            icon: 6,
            time: 1500
        }, function () {
            window.location.href = 'https://vip.wmsgk.com/'
        });
    }, function () {
        layer.open({
            type: 2,
            title: '添加快捷方式 - 2s后关闭',
            shadeClose: true,
            shade: 0.8,
            area: ['50%', '50%'],
            time: 2000,
            content: '/add.php'
        });
    });
}

gg();